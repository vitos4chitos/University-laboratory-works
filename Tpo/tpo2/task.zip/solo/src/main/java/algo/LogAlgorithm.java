package algo;

import entity.LogMessage;
import entity.Operation;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.TimeUnit;

public class LogAlgorithm {
  private List<LogMessage> logMessageList;

  public LogAlgorithm(List<LogMessage> logMessageList) {
    this.logMessageList = logMessageList;
  }

  public List<Operation> solver() throws ParseException {
    Stack<LogMessage> logMessageStack = new Stack<>();
    List<Operation> operations = new ArrayList<>();
    SimpleDateFormat sdfIn = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
    Map<Integer, Operation> map = new HashMap<>();
    List<Long> authenticationTime = new ArrayList<>();
    List<Long> authorizationTime = new ArrayList<>();
    List<Long> balances = new ArrayList<>();

    for (LogMessage message : logMessageList) {
      if (message.getMessage().contains("Operation processing")
          && message.getMessage().contains("has been started")) {
        String m = message.getMessage();
        String id = m.substring(m.indexOf("=") + 1, m.lastIndexOf("]"));
        Date previousLdtAuthorization =
                sdfIn.parse(message.getDate() + " " + message.getTime());
        Date ltdAuthorization = sdfIn.parse(message.getDate() + " " + message.getTime());
        map.put(Integer.parseInt(id), new Operation(id, m, ltdAuthorization.getTime()));
      } else if (message.getMessage().contains("Operation processing")) {
        String m = message.getMessage();
        String id = m.substring(m.indexOf("=") + 1, m.lastIndexOf("]"));
        Operation operation = map.get(Integer.parseInt(id));
        operation.setTimeAuthentication(authenticationTime);
        operation.setTimeAuthorization(authorizationTime);
        operation.setTimeBalances(balances);
        Date previousLdtAuthorization =
                sdfIn.parse(message.getDate() + " " + message.getTime());
        Date ltdAuthorization = sdfIn.parse(message.getDate() + " " + message.getTime());
        operation.setStop(ltdAuthorization.getTime());
        operation.setStatus(!message.getMessage().contains("has been failed"));

        operations.add(operation);

        authenticationTime = new ArrayList<>();
        authorizationTime = new ArrayList<>();
        balances = new ArrayList<>();
      } else if (!logMessageStack.isEmpty()) {
        LogMessage previousMessage = logMessageStack.peek();
        if (message.getMessage().equals("Authentication has been finished.")) {
          transform(sdfIn, authenticationTime, message, previousMessage);
        }
        if (message.getMessage().equals("Authorization has been finished.")) {
          transform(sdfIn, authorizationTime, message, previousMessage);
        }
        if (message.getMessage().equals("Balances modification has been finished.")) {
          transform(sdfIn, balances, message, previousMessage);
        }
        logMessageStack.pop();
      } else {
        logMessageStack.push(message);
      }
    }
    return operations;
  }

  private void transform(SimpleDateFormat sdfIn, List<Long> authorizationTime, LogMessage message, LogMessage previousMessage) throws ParseException {
    Date previousLdtAuthorization =
        sdfIn.parse(previousMessage.getDate() + " " + previousMessage.getTime());
    Date ltdAuthorization = sdfIn.parse(message.getDate() + " " + message.getTime());
    long diff = ltdAuthorization.getTime() - previousLdtAuthorization.getTime();
    TimeUnit time = TimeUnit.MILLISECONDS;
    long difference = time.convert(diff, TimeUnit.MILLISECONDS);
    authorizationTime.add(difference);
  }

  public void verdict(List<Operation> operations) {
    int successfulCounter = 0;
    int failedCounter = 0;
    long avgSuccessfulTimeForAuthentication = 0;
    long avgSuccessfulTimeForAuthorization = 0;
    long avgBalances = 0;
    long avgFailedTimeForAuthentication = 0;
    long avgFailedTimeForAuthorization = 0;
    long avgFailedTimeForBalances = 0;
    long sumAuthentication = 0;
    long sumAuthorization = 0;
    long sumBalances = 0;
    long sumFailedAuthentication = 0;
    long sumFailedAuthorization = 0;
    long sumFailedBalances = 0;
    long allSuccessful = 0;
    long allFailed = 0;
    long avgAllSuccessful = 0;
    long avgAllFailed = 0;
    for (Operation operation : operations) {
      if (operation.isStatus()){
        allSuccessful += operation.getStop() - operation.getStart();

        for (Long l : operation.getTimeAuthentication()) {
          sumAuthentication += l;
        }
        for (Long l : operation.getTimeAuthorization()) {
          sumAuthorization += l;
        }
        for (Long l : operation.getTimeBalances()) {
          sumBalances += l;
        }
        successfulCounter++;

      }
      else {
        allFailed += operation.getStop() - operation.getStart();
        for (Long l : operation.getTimeAuthentication()) {
          sumFailedAuthentication += l;
        }
        for (Long l : operation.getTimeAuthorization()) {
          sumFailedAuthorization += l;
        }
        for (Long l : operation.getTimeBalances()) {
          sumFailedBalances += l;
        }
        failedCounter++;
      }
    }
    avgSuccessfulTimeForAuthentication = sumAuthentication / successfulCounter;
    avgSuccessfulTimeForAuthorization = sumAuthorization / successfulCounter;
    avgBalances = sumBalances / successfulCounter;

    avgFailedTimeForAuthentication += sumFailedAuthentication / failedCounter;
    avgFailedTimeForAuthorization += sumFailedAuthorization / failedCounter;
    avgFailedTimeForBalances += sumFailedBalances / failedCounter;

    avgAllSuccessful = allSuccessful / successfulCounter;
    avgAllFailed = allFailed / failedCounter;

    System.out.println("Successful operation count: " + successfulCounter);
    System.out.println("Average operation successful processing time:" + avgAllSuccessful);
    System.out.println("Failed operation count: " + failedCounter);
    System.out.println("Average operation failed processing time:" + avgAllFailed);
    System.out.println("Average Authentication time (for successful operations): " + avgSuccessfulTimeForAuthentication + "ms");
    System.out.println("Average Authentication time (for failed operations): " + avgFailedTimeForAuthentication + "ms");
    System.out.println("Average Authorization time (for successful operations): " + avgSuccessfulTimeForAuthorization);
    System.out.println("Average Authorization time (for failed operations):" + avgFailedTimeForAuthorization);
    System.out.println("Average Balance modification time (for successful operations):" + avgBalances);
    System.out.println("Average Balance modification time (for failed operations):" + avgFailedTimeForBalances);
  }

  public List<LogMessage> getLogMessageList() {
    return logMessageList;
  }

  public void setLogMessageList(List<LogMessage> logMessageList) {
    this.logMessageList = logMessageList;
  }
}
