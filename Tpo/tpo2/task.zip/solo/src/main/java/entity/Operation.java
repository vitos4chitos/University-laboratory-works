package entity;

import java.util.List;

public class Operation {
  private String id;
  private String name;
  private List<Long> timeAuthentication;
  private List<Long> timeAuthorization;
  private List<Long> timeBalances;
  private boolean status;
  private long start;
  private long stop;

  public long getStart() {
    return start;
  }

  public void setStart(long start) {
    this.start = start;
  }

  public long getStop() {
    return stop;
  }

  public void setStop(long stop) {
    this.stop = stop;
  }

  public boolean isStatus() {
    return status;
  }

  public void setStatus(boolean status) {
    this.status = status;
  }

  public List<Long> getTimeAuthentication() {
    return timeAuthentication;
  }

  public void setTimeAuthentication(List<Long> timeAuthentication) {
    this.timeAuthentication = timeAuthentication;
  }

  public List<Long> getTimeAuthorization() {
    return timeAuthorization;
  }

  public void setTimeAuthorization(List<Long> timeAuthorization) {
    this.timeAuthorization = timeAuthorization;
  }

  public List<Long> getTimeBalances() {
    return timeBalances;
  }

  public void setTimeBalances(List<Long> timeBalances) {
    this.timeBalances = timeBalances;
  }

  public Operation(String id, String name, long start) {
    this.id = id;
    this.name = name;
    this.start = start;
  }

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  @Override
  public String toString() {
    return "Operation{" +
            "id='" + id + '\'' +
            ", name='" + name + '\'' +
            ", timeAuthentication=" + timeAuthentication +
            ", timeAuthorization=" + timeAuthorization +
            ", timeBalances=" + timeBalances +
            ", status=" + status +
            ", start=" + start +
            ", stop=" + stop +
            '}';
  }
}
