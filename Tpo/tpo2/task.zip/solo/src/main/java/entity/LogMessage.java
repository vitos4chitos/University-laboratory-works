package entity;

public class LogMessage {
  private String date;
  private String time;
  private String currentThreadName;
  private String message;

  public LogMessage(String date, String time, String currentThreadName, String message) {
    this.date = date;
    this.time = time;
    this.currentThreadName = currentThreadName;
    this.message = message;
  }

  public LogMessage(){}

  public String getDate() {
    return date;
  }

  public void setDate(String date) {
    this.date = date;
  }

  public String getTime() {
    return time;
  }

  public void setTime(String time) {
    this.time = time;
  }

  public String getCurrentThreadName() {
    return currentThreadName;
  }

  public void setCurrentThreadName(String currentThreadName) {
    this.currentThreadName = currentThreadName;
  }

  public String getMessage() {
    return message;
  }

  public void setMessage(String message) {
    this.message = message;
  }
}
