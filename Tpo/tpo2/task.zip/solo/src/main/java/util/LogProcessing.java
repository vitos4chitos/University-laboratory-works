package util;

import entity.LogMessage;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class LogProcessing {
  private String fileName;

  public LogProcessing(String fileName) {
    this.fileName = fileName;
  }

  public List<LogMessage> process() {
    List<LogMessage> logMessageList = new ArrayList<>();
    try {
      Files.lines(Paths.get(fileName), StandardCharsets.UTF_8)
          .forEach(
              s -> {
                String[] arr = s.split(" ");
                LogMessage logMessage =
                    new LogMessage(
                        arr[0],
                        arr[1],
                        arr[2],
                        String.join(" ", Arrays.copyOfRange(arr, 3, arr.length)));
                logMessageList.add(logMessage);
              });
    } catch (IOException e) {
      e.printStackTrace();
    }
    return logMessageList;
  }


  public String getFileName() {
    return fileName;
  }

  public void setFileName(String fileName) {
    this.fileName = fileName;
  }
}
