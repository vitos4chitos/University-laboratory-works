import algo.LogAlgorithm;
import util.LogProcessing;

import java.text.ParseException;

public class Main {
  public static void main(String[] args) throws ParseException {
    LogProcessing logProcessing = new LogProcessing(args[0]);
    LogAlgorithm logAlgorithm = new LogAlgorithm(logProcessing.process());
    logAlgorithm.verdict(logAlgorithm.solver());
//    logAlgorithm
//        .solver()
//        .forEach(
//                e -> {
//              System.out.println(e.toString());
//            });
  }
}
